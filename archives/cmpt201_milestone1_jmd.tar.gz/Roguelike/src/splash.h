#ifndef SPLASH_H
#define SPLASH_H

#include <ncurses.h>

void show_splash_screen(void);

#endif // SPLASH_H
