#ifndef COLLISION_H
#define COLLISION_H

#include "map.h"

bool check_collision(Map *map, int new_y, int new_x);

#endif // COLLISION_H
