#include "dialogue.h"

// This file will probably just contain a large-ish dictionary of dialogue
// options relevant to whichever type of character will speak it (maybe even
// some generic game subtitles), and some code to select and display the
// dialogue.
