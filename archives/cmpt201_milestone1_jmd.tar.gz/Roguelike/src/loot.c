#include "loot.h"

// This file will contain a list of all the possible loot (armour, weapons,
// potions, etc.), and some logic for looting chests. Maybe also for getting
// gold from enemies, although that might be better suited to the characters
// file (?).
