# Notes

- Main function should perform the initial setup (like calling 'screen_setup'),
  enter the main game loop where the bulk of the game logic will go, and perform
  cleanup and exit when the game loop is exited.

- A way to handle getch input:
```
int main(void) {
    if (screen_setup() != 0) {
        return 1; // Exit if screen setup fails
    }

    // Other setup functions...
    // map_setup();
    // player_setup();

    // Main game loop
    bool game_running = true;
    while (game_running) {
        // Handle input
        int ch = getch();

        // Process the input
        switch (ch) {
            case KEY_UP:
                // move player up
                break;
            case KEY_DOWN:
                // move player down
                break;
            // ... other cases for different inputs
            case 'q':
                game_running = false; // exit the game loop
                break;
        }

        // Update game state
        // ...

        // Render to screen
        // ...
    }

    // Cleanup before exiting
    endwin();
    return 0;
}```

In this structure, getch() is called at the start of each iteration of the game
loop. It waits for a key press and then processes the input. This way, the game
can respond to player actions continuously, and you have the logic in place to
exit the game loop (for instance, when 'q' is pressed, as shown in the example).

The previous placement of getch() before the game loop was more of a placeholder
to demonstrate waiting for any user input before closing the program, which is
typical of simple demonstration programs but not suitable for a game with a
continuous loop.
