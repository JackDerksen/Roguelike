# THIS PROJECT IS UNFINISHED

Use the arrow keys to move, and press 'q' to quit the game.
'E' is an exit which will take you to the next level
'C' is a chest which will give you a random item (placeholder for now)

## Planning in planning.md
